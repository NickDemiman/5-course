from django.db import models
from django.contrib.auth.models import User
from phonenumber_field.modelfields import PhoneNumberField
import datetime

YEAR_OF_STUDY_CHOICES = [
    ('school_1', '1 класс'),
    ('school_2', '2 класс'),
    ('school_3', '3 класс'),
    ('school_4', '4 класс'),
    ('school_5', '5 класс'),
    ('school_6', '6 класс'),
    ('school_7', '7 класс'),
    ('school_8', '8 класс'),
    ('school_9', '9 класс'),
    ('school_10', '10 класс'),
    ('school_11', '11 класс'),

    ('college_1', '1 курс'),
    ('college_2', '2 курс'),
    ('college_3', '3 курс'),
    ('college_4', '4 курс'),
    ('college_5', '5 курс'),
]

class UserProfile(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
    )
    avatar = models.ImageField(
        verbose_name = "Изображение профиля",
        upload_to = "user-avatars/%Y-%m-%d/",
        null=True, blank=True,
    )
    year_of_study = models.CharField(
        verbose_name = "Класс ученика",
        max_length = 255,
        choices=YEAR_OF_STUDY_CHOICES,
        null=True, blank=True,
    )
    school = models.CharField(
        verbose_name = "Название учебного заведения",
        max_length = 255,
        null=True, blank=True,
    )
    phone = PhoneNumberField(
        verbose_name = "Номер телефона ученика",
        null=True, blank=True,
    )
    parent_fio = models.CharField(
        verbose_name = 'ФИО родителя',
        max_length = 255,
    )
    parent_phone = PhoneNumberField(
        verbose_name = 'Номер родителя',
    )
    city = models.CharField(
        verbose_name = 'Город',
        max_length = 255,
    )
    birth_date = models.DateField(
        verbose_name = 'Дата рождения',
    )

    created_at = models.DateTimeField(verbose_name = 'Дата и время создания', auto_now_add = True)
    last_modified = models.DateTimeField(verbose_name = 'Дата и время последнего изменения', auto_now = True)
    
    @property
    def age(self):
        born = self.birth_date
        today = datetime.date.today()
        return today.year - born.year - ((today.month, today.day) < (born.month, born.day))

    class Meta:
        verbose_name = "Профиль пользователя"
        verbose_name_plural = "Профили пользователей"

    def __str__(self):
        return self.user.get_full_name()
