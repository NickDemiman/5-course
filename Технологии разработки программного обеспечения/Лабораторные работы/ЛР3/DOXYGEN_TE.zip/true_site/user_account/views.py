from django.shortcuts import render


def profile_page(request):
    ctx = {
        'sidebar_highlight': 'profile',
        'title': 'Профиль',
    }
    return render(request, 'profile_page.html', ctx)




from rest_framework import viewsets, permissions
from .models import UserProfile 
from .serializers import UserProfileSerializer


class ProfileViewSet(viewsets.ModelViewSet):
    queryset = UserProfile.objects.all()
    serializer_class = UserProfileSerializer
    # permission_classes = [permissions.IsAuthenticated]