from tabnanny import verbose
from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
import datetime

from schedule.models import Subject

from user_account.models import YEAR_OF_STUDY_CHOICES

STUDY_REQUEST_STATUS_CHOICES = [
    ('new', 'Заявка'),
    ('in_process', 'Обработка'),
    ('approved', 'Зачислен'),
    ('declined', 'Отклонён'),
]

class StudyRequest(models.Model):
    subject = models.ForeignKey(
        verbose_name = 'Дисциплина',
        to=Subject,
        on_delete = models.SET_NULL,
        null=True, blank=False
    )

    student_name = models.CharField(
        verbose_name = 'Имя обучающегося',
        max_length = 255,
    )

    student_surname = models.CharField(
        verbose_name = 'Фамилия обучающегося',
        max_length = 255,
    )

    student_phone = PhoneNumberField(
        verbose_name = 'Номер телефона обучающегося',
        null=True, blank=True,
    )

    parent_name = models.CharField(
        verbose_name = 'Имя родителя',
        max_length = 255,
    )

    parent_phone = PhoneNumberField(
        verbose_name = 'Номер телефона родителя',
    )

    school = models.CharField(
        verbose_name = 'Название учебного заведения',
        max_length = 255,
        null=True, blank=True,
    )

    year_of_study = models.CharField(
        verbose_name = 'Год обучения',
        max_length = 255,
        choices = YEAR_OF_STUDY_CHOICES,
        null=True, blank=True,
    )

    city = models.CharField(
        verbose_name = 'Город',
        max_length = 255,
    )

    birth_date = models.DateField(
        verbose_name = 'Дата рождения',
    )

    status = models.CharField(
        verbose_name = 'Статус',
        max_length = 255,
        choices = STUDY_REQUEST_STATUS_CHOICES,
        default = 'new',
    )
    comments = models.CharField(
        verbose_name = 'Комментарии',
        max_length = 4096,
        null=True, blank=True,
    )

    step_1 = models.BooleanField(
        verbose_name = 'Стоимость занятия',
        default=False,
        null=True, blank=True,
    )
    step_2 = models.BooleanField(
        verbose_name = 'Группа',
        default=False,
        null=True, blank=True,
    )
    step_3 = models.BooleanField(
        verbose_name = 'Локация',
        default=False,
        null=True, blank=True,
    )
    step_4 = models.BooleanField(
        verbose_name = 'Расписание',
        default=False,
        null=True, blank=True,
    )


    created_at = models.DateTimeField(verbose_name = 'Дата и время создания', auto_now_add = True)
    last_modified = models.DateTimeField(verbose_name = 'Дата и время последнего изменения', auto_now = True)

    @property
    def age(self):
        born = self.birth_date
        today = datetime.date.today()
        return today.year - born.year - ((today.month, today.day) < (born.month, born.day))

    def __str__(self):
        return f"{self.get_status_display()} | {self.student_name} {self.student_surname}. Звонить: {self.parent_name}, {self.parent_phone}."

    class Meta:
        verbose_name = 'Заявка на обучение'
        verbose_name_plural = 'Заявки на обучение'
