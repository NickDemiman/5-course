from .models import StudyRequest
from rest_framework import serializers

class StudyRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudyRequest
        exclude = []