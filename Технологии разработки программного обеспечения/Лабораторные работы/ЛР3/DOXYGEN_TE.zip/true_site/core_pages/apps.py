from django.apps import AppConfig


class CorePagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core_pages'
    verbose_name = 'Основные страницы'
