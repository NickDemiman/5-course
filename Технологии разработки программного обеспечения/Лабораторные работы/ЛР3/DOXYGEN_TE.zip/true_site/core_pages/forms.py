from django.forms import ModelForm
from .models import StudyRequest

class RequestForm(ModelForm):
    class Meta:
        model = StudyRequest
        exclude = ['status', 'creation_date', 'comments', 'student_phone', 'year_of_study', 'step_1', 'step_2', 'step_3', 'step_4']