from django.contrib import admin
from .models import StudyRequest

admin.site.register([
    StudyRequest,
])

# Register your models here.
