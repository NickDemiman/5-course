from django.shortcuts import render, HttpResponseRedirect
from .models import StudyRequest
from .forms import RequestForm



def welcome_page(request):
    ctx = {
        'sidebar_highlight': 'welcome_page',
    }
    ctx['page'] = {
            'title': 'Главная',
            'description': 'True Electronics - добро пожаловать!',
        }
    return render(request, 'welcome_page.html', ctx)


def request_form(request):
    if request.method == 'POST':
        form = RequestForm(request.POST)
        if form.is_valid():
            cleaned_data = form.cleaned_data
            new_request = StudyRequest(**cleaned_data)
            new_request.save()
            return HttpResponseRedirect('/')

    else:
        form = RequestForm()

    ctx = {
        'sidebar_highlight': 'welcome_page',
        'form': form,
    }
    ctx['page'] = {
            'title': 'Подать заявку',
            'description': 'True Electronics - подайте заявку на обучение!.',
        }
    return render(request, 'request_form.html', ctx)




from rest_framework import viewsets, permissions
from .serializers import StudyRequestSerializer


class StudyRequestViewSet(viewsets.ModelViewSet):
    queryset = StudyRequest.objects.all()
    serializer_class = StudyRequestSerializer
    # permission_classes = [permissions.IsAuthenticated]