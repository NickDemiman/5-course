from django.contrib import admin
from django.urls import path, include

from rest_framework import routers

from user_account import views as profile_views
from core_pages import views as core_views
from schedule import views as schedule_views

router = routers.DefaultRouter()
router.register(r'users', profile_views.ProfileViewSet)
router.register(r'study-requests', core_views.StudyRequestViewSet)
router.register(r'subjects', schedule_views.SubjectViewSet)
router.register(r'study-groups', schedule_views.StudyGroupViewSet)
router.register(r'enrollments', schedule_views.EnrollmentViewSet)
router.register(r'lessons', schedule_views.LessonViewSet)
router.register(r'attendances', schedule_views.AttendanceViewSet)

urlpatterns = [
    # path('', include('core_pages.urls')),
    # path('profile/', include('user_account.urls')),
    # path('schedule/', include('schedule.urls')),

    path('admin/', admin.site.urls),

    path('api/', include(router.urls)),
    path('api/', include('rest_framework.urls', namespace='rest_framework')),
    
]
