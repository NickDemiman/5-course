from django.db import models
from django.contrib.auth.models import User
import datetime as dt

##
# @page models Модели
# @file models.py
#
# @brief В данном файле описаны Django модели, обеспечивающие интерфейс доступа к базе данных
#
# @section schedule_model_libs Используемые библиотеки
# - datetime
# - auth.models.User django model
#
#


class Subject(models.Model):
    """! Дисциплина обучения
        Интерфейс доступа к объекту БД "Дисциплина обучения"
    """

    ## Название дисциплины
    name = models.CharField(
        verbose_name = 'Название',
        max_length = 255,
    )

    ## Дата создания объекта
    created_at = models.DateTimeField(verbose_name = 'Дата и время создания', auto_now_add = True)
    ## Дата последнего изменения объекта
    last_modified = models.DateTimeField(verbose_name = 'Дата и время последнего изменения', auto_now = True)

    class Meta:
        """! Мета-информация для корректного отображения в панели администратора
        """
        verbose_name = "Изучаемая дисциплина"
        verbose_name_plural = "Изучаемые дисциплины"

    def __str__(self):
        return self.name

## 
# @brief Группа обучения.
# 
# Интерфейс доступа к объекту БД "Группа обучения".
#
class StudyGroup(models.Model):
    
    
    ## FK "Изучаемая дисциплина"
    subject = models.ForeignKey(
        Subject,
        verbose_name = "Изучаемый предмет",
        on_delete = models.SET_NULL,
        null=True, blank=True,
    )

    ## Название группы
    name = models.CharField(
        verbose_name = 'Название',
        max_length = 255,
    )

    ## Уровень группы. Например: Новички, Средние, Старшие.
    level = models.CharField(
        verbose_name = "Уровень группы",
        max_length = 255,
        null=True, blank=True,
    )

    ## Максимальное количество человек в группе.
    capacity = models.IntegerField(
        verbose_name = 'Вместимость',
    )

    created_at = models.DateTimeField(verbose_name = 'Дата и время создания', auto_now_add = True)
    last_modified = models.DateTimeField(verbose_name = 'Дата и время последнего изменения', auto_now = True)

    ## Количество мест доступных для записи в группу.
    #
    # @param self Ссылка на переданный объект.
    #
    # @throw aslfkjs;dlkjsad adkjflskdjf
    #
    # @return Количество мест.
    @property
    def vacant_count(self):
        group_enrollments = self.enrollment_set.filter(deleted=False)
        busy_count = len(group_enrollments)
        return self.capacity - busy_count

    @property
    def students_count(self):
        """! Количество студентов в группе.

        @return Количество студентов
        """

        ## Список записей в группу
        group_enrollments = self.enrollment_set.filter(deleted=False)
        ## Количество записей в группу
        busy_count = len(group_enrollments)
        return busy_count

    class Meta:
        """! Мета-информация.
        Мета-информация для корректного отображения в панели администратора
        """
        verbose_name = "Группа учеников"
        verbose_name_plural = "Группы учеников"

    def __str__(self):
        return f"{self.name} | {self.subject} | {self.level}"

    @property
    def max_age(self):
        """! Максимальный возраст студента в группе.

        @return Максимальный возраст.
        """
        enrollments = self.enrollment_set.all()
        ages = [enrollment.student.userprofile.age for enrollment in enrollments]
        return max(ages) if ages else None

    @property
    def min_age(self):
        """! Минимальный возраст студента в группе

        @return Минимальный возраст
        """
        enrollments = self.enrollment_set.all()
        ages = [enrollment.student.userprofile.age for enrollment in enrollments]
        return min(ages) if ages else None

class Enrollment(models.Model):
    """! Запись студента в группу.
        Интерфейс доступа к объекту БД "Запись студента в группу"
    """

    ## FK "Ученик"
    student = models.ForeignKey(
        User,
        verbose_name = 'Связанный пользователь (ученик)',
        on_delete = models.SET_NULL,
        null = True,
        blank = True,
    )

    ## FK "Группа"
    group = models.ForeignKey(
        StudyGroup,
        verbose_name = 'Связанная группа',
        on_delete = models.SET_NULL,
        null = True,
        blank = True,
    )

    ## Стоимость занятия
    lesson_cost = models.DecimalField(
        verbose_name = 'Стоимость занятий',
        decimal_places = 2,
        max_digits = 10,
        null=True, blank=True,
    )

    ## Статус занятия "удалено"
    deleted = models.BooleanField(
        verbose_name = 'Удален',
        default = False,
    )

    ## Дата создания объекта
    created_at = models.DateTimeField(verbose_name = 'Дата и время создания', auto_now_add = True)
    ## Дата последнего изменения объекта
    last_modified = models.DateTimeField(verbose_name = 'Дата и время последнего изменения', auto_now = True)

    class Meta:
        """! Мета-информация
        Мета-информация для корректного отображения в панели администратора
        """
        verbose_name = "Запись в группу"
        verbose_name_plural = "Записи в группу"

    def __str__(self):
        return f"{self.student.get_full_name()} записан в группу {self.group.name}. Стоимость занятия: {self.lesson_cost}."

class Lesson(models.Model):
    """! Занятие
        Интерфейс доступа к объекту БД "Занятие"
    """

    ## FK "Группа"
    group = models.ForeignKey(
        StudyGroup,
        verbose_name = 'Группа',
        on_delete = models.SET_NULL,
        null=True, blank=True,
    )

    ## Тема занятия
    topic = models.CharField(
        verbose_name = 'Тема',
        max_length = 255,
        null=True, blank=True,
    )

    ## Дата и время проведения занятия
    datetime = models.DateTimeField(
        verbose_name = 'Дата и время начала',
    )

    ## Длительность занятия
    duration = models.DurationField(
        verbose_name = 'Длительность занятия',
        null=True, blank=True,
        default = dt.timedelta(hours=1, minutes=30),
    )

    ## Дата создания объекта
    created_at = models.DateTimeField(verbose_name = 'Дата и время создания', auto_now_add = True)
    ## Дата последнего изменения объекта
    last_modified = models.DateTimeField(verbose_name = 'Дата и время последнего изменения', auto_now = True)

    class Meta:
        """! Мета-информация
        Мета-информация для корректного отображения в панели администратора
        """
        verbose_name = "Занятие"
        verbose_name_plural = "Занятия"

    ## Время начала занятия
    @property
    def start_time(self):
        return self.datetime.time()

    ## Время окончания занятия
    @property
    def end_time(self):
        return (self.datetime + self.duration).time()

    def __str__(self):
        return f"{self.group.name} | {self.datetime.date()} | {self.datetime.time()}"

class Attendance(models.Model):
    """! Посещение
        Интерфейс доступа к объекту БД "Посещение"
    """

    ## FK "Занятие"
    lesson = models.ForeignKey(
        Lesson,
        verbose_name = 'Занятие',
        on_delete = models.SET_NULL,
        null=True, blank=True,
    )

    ## FK "Ученик"
    student = models.ForeignKey(
        User,
        verbose_name = 'Пользователь (ученик)',
        on_delete = models.SET_NULL,
        null=True, blank=True,
    )

    # TODO: Стоимость должна заполняться в момент создания объекта посещения
    ## Стоимость занятия
    cost = models.DecimalField(
        verbose_name = 'Стоимость занятий',
        decimal_places = 2,
        max_digits = 10,
        default = 110,
        null=True, blank=True,
    )

    ## Дата создания объекта
    created_at = models.DateTimeField(verbose_name = 'Дата и время создания', auto_now_add = True)
    ## Дата последнего изменения объекта
    last_modified = models.DateTimeField(verbose_name = 'Дата и время последнего изменения', auto_now = True)
    
    class Meta:
        verbose_name = "Посещение"
        verbose_name_plural = "Посещения"

    def set_cost(self):
        """! Устанавливает стоимость занятия.
            Стоимость занятия устанавливается на основе стоимости одного занятия в соответствующей группе.
        """
        enrollment_set = self.student.enrollment_set.all()
        _group = self.lesson.group

        enrollment = enrollment_set.get(group=_group)
        self.cost = enrollment.lesson_cost

    def __str__(self):
        return f"{self.student} посетил {self.lesson}"