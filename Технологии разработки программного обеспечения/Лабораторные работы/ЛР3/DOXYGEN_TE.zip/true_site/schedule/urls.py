from django.urls import path
from . import views

urlpatterns = [
    path('', views.schedule_page, name='schedule'),

    path('requests', views.study_requests, name='study_requests'),
    path('requests/update/<int:pk>', views.study_requests_modify, name='study_request_modify'),
    
    path('work-schedule', views.work_schedule, name='work_schedule'),
    path('work-schedule/ajax/calendar', views.work_schedule_get_calendar, name="work_schedule_get_calendar"),
    path('work-schedule/ajax/lesson_list', views.work_schedule_get_lesson_list, name="work_schedule_get_lesson_list"),
]