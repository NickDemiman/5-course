from django.shortcuts import render
from django.http import HttpResponse, Http404, HttpResponseBadRequest
from core_pages.models import StudyRequest
from schedule.models import Enrollment, Lesson, StudyGroup, Subject, Attendance
from dateutil.relativedelta import relativedelta

import datetime


def schedule_page(request):
    ctx = {
        'sidebar_highlight': 'schedule',
    }
    return render(request, 'schedule_page.html', ctx)

def study_requests(request):
    requests = StudyRequest.objects.all()
    request_status_permitted = ['new', 'in_process']
    requests = requests.filter(status__in = request_status_permitted)
    groups = StudyGroup.objects.all()
    subjects = Subject.objects.all()

    ctx = {
        'sidebar_highlight': 'study_requests',
        'subject_dict': {},
        'subjects': subjects,
    }

    ctx['page'] = {
        'title': 'Заявки на курсы',
        'description': 'Просмотр оставленных заявок с фильтром по дисциплине обучения.',
    }

    for subject in subjects:
        filtered_subject_requests        = requests.filter(subject=subject).order_by('created_at__date', '-status', 'created_at__time')

        all_subject_requests    = StudyRequest.objects.filter(subject=subject)
        requests_month          = all_subject_requests.filter(created_at__date__gte=datetime.date.today() - relativedelta(months=1))
        requests_half_year      = all_subject_requests.filter(created_at__date__gte=datetime.date.today() - relativedelta(months=6))
        requests_year           = all_subject_requests.filter(created_at__date__gte=datetime.date.today() - relativedelta(years=1))

        ctx['subject_dict'][subject.name] = {
            'pk': subject.pk,
            'requests': filtered_subject_requests,
            'groups': groups.filter(subject=subject),
            'request_count': {
                'all':              len(all_subject_requests),
                'in_process':       len(all_subject_requests.filter(status='in_process')),
                'approved':         len(all_subject_requests.filter(status='approved')),
                'declined':         len(all_subject_requests.filter(status='declined')),
                'by_period': {
                    'month': {
                        'name':             'месяц',
                        'all':              len(requests_month),
                        'in_process':       len(requests_month.filter(status='in_process')),
                        'approved':         len(requests_month.filter(status='approved')),
                        'declined':         len(requests_month.filter(status='declined')),
                    },
                    'half_year': {
                        'name':             'полгода',
                        'all':              len(requests_half_year),
                        'in_process':       len(requests_half_year.filter(status='in_process')),
                        'approved':         len(requests_half_year.filter(status='approved')),
                        'declined':         len(requests_half_year.filter(status='declined')),
                    },
                    'year': {
                        'name':             'год',
                        'all':              len(requests_year),
                        'in_process':       len(requests_year.filter(status='in_process')),
                        'approved':         len(requests_year.filter(status='approved')),
                        'declined':         len(requests_year.filter(status='declined')),
                    },
                },
            }
        }
    return render(request, 'study_requests.html', ctx)

def study_requests_modify(request, pk):
    if request.method == "POST":
        description = request.POST.get('description')
        step_1 = request.POST.get('step_1')
        step_2 = request.POST.get('step_2')
        step_3 = request.POST.get('step_3')
        step_4 = request.POST.get('step_4')
        
        study_request = StudyRequest.objects.get(pk=pk)

        study_request.comments = description

        # Заявка переводится в обработку после того, как ученику сообщили об условиях проведения занятий
        if step_1 == 'True':
            study_request.step_1 = True 
            study_request.status = 'in_process'
        else:
            study_request.step_1 = False 

        if step_2 == 'True':
            study_request.step_2 = True 
            study_request.status = 'in_process'
        else:
            study_request.step_2 = False 

        if step_3 == 'True':
            study_request.step_3 = True 
            study_request.status = 'in_process'
        else:
            study_request.step_3 = False 

        if step_4 == 'True':
            study_request.step_4 = True 
            study_request.status = 'in_process'
        else:
            study_request.step_4 = False 
        
        study_request.save()
        return HttpResponse('Added')

    return HttpResponse('OK')

def work_schedule(request):
    
    lessons = Lesson.objects.filter(datetime__gte = datetime.datetime.today())[:10]
    
    ctx = {
        'sidebar_highlight': 'work_schedule',
        'lessons': lessons,
    }

    ctx['page'] = {
        'title': 'Рабочий график',
        'description': 'Расписание преподавателя. Планирование занятий.',
    }

    
    return render(request, 'work_schedule.html', ctx)

def work_schedule_get_calendar(request):

    CALENDAR_ROW_COUNT = 9
    CALENDAR_WEEK_OFFSET = -2

    if request.method == 'GET':
        today = datetime.datetime.today()

        _option = request.GET.get('option')
        if _option == 'today':
            _month  = today.month
            _year   = today.year
        else:
            _month = int(request.GET.get('month'))
            _year = int(request.GET.get('year'))

        first_month_day = datetime.datetime(year=_year, month=_month, day=1)
        if _option == 'load_previous': 
            first_month_day -= relativedelta(months=1)
        if _option == 'load_next': 
            first_month_day += relativedelta(months=1)


        _year = first_month_day.year
        _month = first_month_day.month

        first_weekday = first_month_day.weekday()
        day_offset = first_weekday

        calendar_page = {
            'weeks': [],
        }

        lessons = Lesson.objects.all()

        for week_num in range(CALENDAR_ROW_COUNT):
            new_week = {'days': []}

            for day_num in range(7):
                new_day = first_month_day + relativedelta(days = day_num + (week_num + CALENDAR_WEEK_OFFSET) * 7 - day_offset )
                new_day_dict = {
                    'day': new_day.day,
                    'today': new_day.date() == today.date(),
                    'prev_month': new_day.month == (first_month_day - relativedelta(months = 1)).month,
                    'next_month': new_day.month == (first_month_day + relativedelta(months = 1)).month,
                    'load': len(lessons.filter(datetime__date=new_day.date())),
                    'date': new_day,
                }
                new_week['days'].append(new_day_dict)

            calendar_page['weeks'].append(new_week)

        ctx = {
            'calendar': calendar_page,
            'year': _year,
            'month': _month,
            'date': first_month_day,
        }

        return render(request, 'work_schedule__calendar.html', ctx)

    else:
        raise Http404

def work_schedule_get_lesson_list(request):
    
    if request.method == "GET":
        
        _year = int(request.GET.get('year'))
        _month = int(request.GET.get('month'))
        _day = int(request.GET.get('day'))
        _option = request.GET.get('option')

        if _year == 0 and _month == 0 and _day == 0:
            lesson_date = datetime.datetime.today().date()
        else:
            lesson_date = datetime.date(year = _year, month = _month, day = 1)
            if _option == 'load_previous':
                lesson_date -= relativedelta(months = 1)
            elif _option == 'load_next':
                lesson_date += relativedelta(months = 1)

            lesson_date -= relativedelta(day=_day)

        lessons = Lesson.objects.filter(datetime__date = lesson_date)
        ctx = {
            'date': lesson_date,
            'lessons': lessons,
        }
        return render(request, 'work_schedule__lesson_list.html', ctx)
    
    else:
        raise Http404()


from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, permissions, generics
from .serializers import SubjectSerializer, StudyGroupSerializer, EnrollmentSerializer,\
                            LessonSerializer, AttendanceSerializer
from rest_framework.response import Response
class SubjectViewSet(viewsets.ModelViewSet):
    queryset = Subject.objects.all()
    serializer_class = SubjectSerializer
    # permission_classes = [permissions.IsAuthenticated]

class StudyGroupViewSet(viewsets.ModelViewSet):
    queryset = StudyGroup.objects.all()
    serializer_class = StudyGroupSerializer
    # permission_classes = [permissions.IsAuthenticated]

class EnrollmentViewSet(viewsets.ModelViewSet):
    queryset = Enrollment.objects.all()
    serializer_class = EnrollmentSerializer
    # permission_classes = [permissions.IsAuthenticated]

class LessonViewSet(viewsets.ModelViewSet):
    queryset = Lesson.objects.all()
    serializer_class = LessonSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = {
        'id': ['exact'], 
        'group': ['exact'], 
        'datetime': ['gte', 'lte', 'lt', 'gt', 'exact']
    }

    # def list(self, request):
    #     queryset = Lesson.objects.all()
        
    #     date_filter_str = request.GET.get('date')
    #     if date_filter_str:
    #         date_filter_obj = datetime.date.fromisoformat(date_filter_str)
    #         queryset = queryset.filter(datetime__date = date_filter_obj)

    #     serializer = LessonSerializer(queryset, many=True)
    #     return Response(serializer.data)
    # permission_classes = [permissions.IsAuthenticated]

class AttendanceViewSet(viewsets.ModelViewSet):
    queryset = Attendance.objects.all()
    serializer_class = AttendanceSerializer
    # permission_classes = [permissions.IsAuthenticated]