from .models import Subject, StudyGroup, Enrollment, Lesson, Attendance
from rest_framework import serializers

class SubjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subject
        exclude = []

class StudyGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudyGroup
        exclude = []

class EnrollmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Enrollment
        exclude = []

class LessonSerializer(serializers.ModelSerializer):
    group = StudyGroupSerializer(read_only=True)
    date = serializers.SerializerMethodField('get_lesson_date')

    def get_lesson_date(self, lesson):
        return lesson.datetime.date()
    class Meta:
        model = Lesson
        fields = '__all__'

class AttendanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attendance
        exclude = []