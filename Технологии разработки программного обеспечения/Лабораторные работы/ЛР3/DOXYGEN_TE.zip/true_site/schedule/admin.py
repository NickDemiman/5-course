from django.contrib import admin
from .models import Subject, StudyGroup, Lesson, Attendance, Enrollment

admin.site.register([
    Subject,
    StudyGroup,
    Lesson,
    Attendance,
    Enrollment
])
