from django.core.management.base import BaseCommand
from faker import Faker

from schedule.models import Subject
from user_account.models import YEAR_OF_STUDY_CHOICES
from random import randint, choice, random
from dateutil.relativedelta import relativedelta

faker = Faker('ru_RU')

def generate_study_request():
    from core_pages.models import StudyRequest
    SCHOOL_LIST = [
        'Школа №1',
        'Школа №2',
        'Гимназия г. Раменское',
        'Гимназия г. Мытищи',
        'Гимназия г. Королёв',
        'Гимназия г. Егорьевск',
        'Гимназия г. Гжель',
        'Школа №3',
        'Школа №4',
        'Школа №5',
        'Школа №6',
        'Школа №7',
        'Школа №8',
        'Школа №9',
        'Школа №10',
        'Школа №11',
        'Школа №12',
        'Школа №13',
        'Школа №14',
        'Школа №15',
        'Гимназия №1',
        'Гимназия №2',
        'Гимназия №3',
        'Гимназия №4',
        'Гимназия №10',
        ]
    YEAR_OF_STUDY_LIST = [el[0] for el in YEAR_OF_STUDY_CHOICES if el[0].startswith('school')]
    CITY_LIST = [
        'г. Раменское',
        'г. Москва',
        'г. Егорьевск',
        'г. Мытищи',
        'г. Гжель',
        'г. Королёв',
        'г. Санкт-Петербург',
        'д. Спас-Клепики',
        'г. Днепропетровск',
    ]

    subject = choice(list(Subject.objects.all()))


    student_phone = f"+79{randint(100000000, 999999999)}"
    parent_phone = f"+79{randint(100000000, 999999999)}"
    age = randint(8, 17)
    birth_date = faker.date_time_this_year() - relativedelta(years=age)
    
    status_prob = random() * 10
    status = 'new'
    if status_prob >= 0 and status_prob < 3:
        status = 'in_process'
    elif status_prob >= 3 and status_prob < 5:
        status = 'approved'
    elif status_prob >= 5 and status_prob < 6:
        status = 'declined'

    data = {
        'subject':              subject,
        'student_name':         faker.first_name(),
        'student_surname':      faker.last_name(),
        'student_phone':        student_phone,
        'parent_name':          faker.first_name(),
        'parent_phone':         parent_phone,
        'school':               choice(SCHOOL_LIST),
        'year_of_study':        choice(YEAR_OF_STUDY_LIST),
        'city':                 choice(CITY_LIST),
        'birth_date':           birth_date,
        'status':               status,
        'comments':             '',
    }

    new_request = StudyRequest(**data)
    new_request.save()
    


VALID_MODELS = {
    'StudyRequest': generate_study_request
}

class Command(BaseCommand):
    help = """
    Создает указанное количество объектов.
    На данный момент доступны:
        - Заявки на обучение
    """

    def handle(self, *args, **options):
        gen_model = options['model']
        gen_count = options['count']

        if gen_model not in VALID_MODELS:
            raise ValueError('Некорректная модель или не поддерживает генерацию')

        for i in range(gen_count):
            handler = VALID_MODELS[gen_model]
            handler()

    def add_arguments(self, parser):
        parser.add_argument('model', type=str, help="Модель, для которой будут созданы объекты")
        parser.add_argument('count', type=int, help="Количество создаваемых объектов")


    