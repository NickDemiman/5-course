##
# @page Backend
# @brief Информация о бекэнд части проекта
# 
# В качестве backend фреймворка используется Django + Django Rest Api
#
# @section django_models Модели Django
# - @link models.py @endlink