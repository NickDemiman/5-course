##
# @mainpage Информация о проекте
#
# @section main_description Информация
# @brief Информационная система для ведения учета посещений, успеваемости, оплаты занятий курсов по программированию микроконтроллеров
# @author Denis Vasilev
# @date 2022-10-26
# 
# @section main_contents Состав проекта
# @par Проект разделен на следующие части:
# - @ref Frontend
# - @ref Backend